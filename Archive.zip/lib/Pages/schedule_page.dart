import 'package:flutter/material.dart';
import 'package:weekly_timetable/weekly_timetable.dart';

void main() => runApp(SchedulePage());

class SchedulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: MyHomePage(title: 'Flutter TimeTable Plugin Example'),
        debugShowCheckedModeBanner: false
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Map<int, List<int>> initialSchedule = {
    0: [342],
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
    6: [],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: WeeklyTimeTable (initialSchedule: initialSchedule),
    );
  }
}